#!/system/xbin/bash
#!/system/xbin/botbrew
apt-get update && upgrade -y
apt-get install python2 -y
apt-get install toilet -y
apt-get install php -y
apt-get install figlet
pip2 install requests
pip2 install mechanize
pkg install ruby
gem install lolcat
